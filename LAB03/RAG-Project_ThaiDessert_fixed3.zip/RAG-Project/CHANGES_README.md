# สรุปสิ่งที่แก้ไข (RAG-Project ขนมไทย)

## สาเหตุที่ถามแล้วไม่ตรงคำถามขนมไทย
ไฟล์ `vector_db/document.index` และ `vector_db/chunk_store.json` (รวมถึง
`outputs/embeddings.npy`) ที่แนบมา **ถูกสร้างจากไฟล์ `data/sex_q_a.txt`**
(ชุดข้อมูลสุขภาพทางเพศ) ไม่ใช่จาก `data/thai_dessert_qa.txt` — ทั้งที่
`config.py` ตั้งค่า `SOURCE_FILE` ไปที่ `thai_dessert_qa.txt` ถูกต้องแล้ว
แต่ไฟล์ vector database ที่มีอยู่ไม่ได้ถูก build ใหม่หลังเปลี่ยนไฟล์ต้นทาง
เลยทำให้ระบบค้นคืนคำตอบเรื่องสุขภาพทางเพศแทนที่จะเป็นขนมไทย

ระบบ `document_loader.py` และ `text_splitter.py` เองไม่มีบั๊ก — ทดสอบกับ
`thai_dessert_qa.txt` แล้วอ่านได้ครบ 300 คู่ถาม-ตอบ และแบ่ง chunk ได้ถูกต้อง

## สิ่งที่แก้ไขแล้วในโค้ด
- `main.py`
  - ข้อความหัวโปรแกรมที่ค้างจากเทมเพลตเดิม ("RAG System for Sexual Health...")
    → เปลี่ยนเป็นข้อความเกี่ยวกับขนมไทย
  - `top_k=1` ที่ถูก hardcode ไว้ → กลับไปใช้ `config.TOP_K` (=3) ตามที่ตั้งใจไว้เดิม
  - เพิ่มการแสดง `Category` และ `Similar Question` กลับมา (ถูกคอมเมนต์ทิ้งไว้)
    ช่วยให้เช็คได้ว่าคำตอบที่ได้ตรงประเด็นไหม
  - ข้อความแจ้งเตือนตอนยังไม่มี vector database ถูกคอมเมนต์ทิ้งไว้ ทำให้โปรแกรม
    เงียบและปิดตัวเฉยๆ → เอากลับมาแสดงผล
- `labs/lab05_query_embedding.py`, `lab06_similarity_search.py`,
  `lab07_complete_retrieval.py` — คำถามตัวอย่างเดิมเป็นคำถามสุขภาพทางเพศ
  (ถุงยางอนามัย, PrEP/PEP ฯลฯ) ซึ่งไม่เกี่ยวกับ dataset ขนมไทยเลย
  → เปลี่ยนเป็นคำถามเกี่ยวกับขนมไทยแทน
- ลบ `outputs/embeddings.npy`, `outputs/retrieval_results.json`,
  `vector_db/document.index`, `vector_db/chunk_store.json` ที่ค้างจากข้อมูลผิด
  ออกไป (ต้อง build ใหม่)
- รัน `lab01_extract_text.py` และ `lab02_chunking.py` ให้ใหม่แล้ว จากไฟล์
  `thai_dessert_qa.txt` ที่ถูกต้อง → ได้ `outputs/extracted_text.json` และ
  `outputs/chunks.json` ใหม่ (300 คู่ถาม-ตอบ, 300 chunks) แนบมาให้พร้อมใช้แล้ว

## หมายเหตุ: data/sex_q_a.txt
มีไฟล์นี้ค้างอยู่ใน `data/` แต่ `config.py` ไม่ได้อ้างถึงไฟล์นี้เลย (ไม่ถูกใช้
ในไปป์ไลน์) น่าจะเป็นไฟล์ที่หลงเหลือจากโปรเจกต์/แบบฝึกหัดอื่น — ถ้าไม่ได้ใช้
แล้วลบออกจากโฟลเดอร์ `data/` ได้เลยเพื่อความเรียบร้อย

## สิ่งที่ต้องทำต่อ (รันบนเครื่องคุณเอง)
sentence-transformers และ faiss-cpu ต้องโหลดโมเดล/ไลบรารีจากอินเทอร์เน็ต
ซึ่ง sandbox นี้ไม่มีการเชื่อมต่อเน็ต จึงรันให้ไม่ได้ในขั้นตอนนี้ ให้รันคำสั่ง
ต่อไปนี้บนเครื่องของคุณ (จากโฟลเดอร์ `RAG-Project/`):

```bash
pip install -r requirements.txt

python labs/lab03_create_embeddings.py   # สร้าง outputs/embeddings.npy
python labs/lab04_create_vector_db.py    # สร้าง vector_db/document.index และ chunk_store.json

python main.py                           # เริ่มถาม-ตอบขนมไทยได้เลย
```

(lab01 กับ lab02 รันให้แล้ว ไม่ต้องรันซ้ำ เว้นแต่จะแก้ไข `data/thai_dessert_qa.txt`
เพิ่มเติม — ถ้าแก้ข้อมูลใหม่ ให้รันตั้งแต่ lab01 ใหม่ทั้งหมด)
